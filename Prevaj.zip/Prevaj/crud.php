<?php 
include("database.php");
if($_POST['crud'] == "insert"){

$name = $_POST['name']; 
$salary = $_POST['salary'];
$role = $_POST['role'];
$company = $_POST['company'];

$stmt = $connection->prepare("INSERT INTO person (name, salary, role, company) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $salary, $role, $company);
$stmt->execute();

$stmt->close();
$connection->close();

// Redirect or return a response indicating the success or any errors, if needed

}

elseif($_POST['crud']== 'delete'){
    
$id = $_POST['id'];
$stmt = $connection->prepare("DELETE FROM person WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

$stmt->close();
$connection->close();

}
elseif($_POST['crud']=='edit'){
    $id = $_POST['id'];
    $name = $_POST['name']; 
$salary = $_POST['salary'];
$role = $_POST['role'];
$company = $_POST['company'];
$stmt = $connection->prepare("UPDATE person SET name = ?, role = ?, company = ?, salary = ? WHERE id = ?");
$stmt->bind_param("ssssi", $name, $role, $company, $salary, $id);
$stmt->execute();

$stmt->close();
$connection->close();

}
?>