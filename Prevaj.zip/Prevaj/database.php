<?php
$hostname = '127.0.0.1'; // MySQL server hostname
$username = 'root'; // MySQL username
$password = ''; // MySQL password
$database = 'prevaj'; // MySQL database name

$connection = mysqli_connect($hostname, $username, $password, $database);

if (!$connection) {
  die('Error connecting to the database: ' . mysqli_connect_error());
}

?>
