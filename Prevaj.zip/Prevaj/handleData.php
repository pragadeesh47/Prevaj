<?php
include("database.php");

$data = json_decode(file_get_contents('php://input'));


$stmt = $connection->prepare("SELECT * FROM person");
$stmt->execute();
$result = $stmt->get_result();

$rows = array(); // Initialize an empty array to store the rows

while ($row = $result->fetch_assoc()) {
    $rows[] = $row; // Add each row to the array
}
echo json_encode($rows);

$stmt->close();

$connection ->close();

?>