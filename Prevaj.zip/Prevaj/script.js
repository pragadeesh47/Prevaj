// Sample data
document.querySelector(".add-btn").onclick = () =>{
  window.location.href = "http://localhost/Prevaj/form.html";
 }
      window.onload = () =>{
          const crud = "read"; // Example input value

fetch('http://localhost/Prevaj/handleData.php', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
},
})
.then(response => response.json())
.then(data => {
// Process the retrieved data
  // displayData(data)
  
  // Constants
  const itemsPerPage = 3; // Number of items to display per page
  
  // Track current page and sort options
  let currentPage = 1;
  let sortKey = "name";
  let sortOrder = "asc";
  
  // Function to display data
  function displayData() {
    const dataContainer = document.querySelector("#data tbody");
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const sortedData = data.slice().sort((a, b) => {
      const aValue = sortOrder === "asc" ? a[sortKey] : b[sortKey];
      const bValue = sortOrder === "asc" ? b[sortKey] : a[sortKey];
      if (typeof aValue === "string") {
        return aValue.localeCompare(bValue);
      } else {
        return aValue - bValue;
      }
    });
    const paginatedData = sortedData.slice(startIndex, endIndex);
  
    dataContainer.innerHTML = ""; // Clear previous data
  let i =0;
    paginatedData.forEach(item => {
      const row = document.createElement("tr");
      const indexCell = document.createElement("td");
      const nameCell = document.createElement("td");
      const roleCell = document.createElement("td");
      const companyCell = document.createElement("td");
      const salaryCell = document.createElement("td");
      const editCell = document.createElement("td");
      const deleteCell = document.createElement("td");
  
      indexCell.textContent = item.id;
      nameCell.textContent = item.name;
      roleCell.textContent = item.role;
      companyCell.textContent = item.company;
      salaryCell.textContent = item.salary;
      editCell.innerHTML =  `<img onclick =  "handleEdit('${item.id}', '${item.name}', '${item.role}', '${item.company}', '${item.salary}')"  src="http://localhost/Prevaj/assets/draw.png"/>`;
      deleteCell.innerHTML =`<img onclick = "handleDelete(${item.id})" src="http://localhost/Prevaj/assets/trash.png"/>`;
  
      row.appendChild(indexCell);
      row.appendChild(nameCell);
      row.appendChild(roleCell);
      row.appendChild(companyCell);
      row.appendChild(salaryCell);
      row.appendChild(editCell);
      row.appendChild(deleteCell);
      dataContainer.appendChild(row);
    });
  }
  
  // Function to display pagination links
  function displayPagination() {
    const totalItems = data.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const paginationContainer = document.getElementById("pagination");
    paginationContainer.innerHTML = ""; // Clear previous pagination
  
    for (let page = 1; page <= totalPages; page++) {
      const pageLink = document.createElement("span");
      pageLink.classList.add("page-link");
      pageLink.textContent = page;
      pageLink.addEventListener("click", () => {
        currentPage = page;
        displayData();
        highlightPageLink(currentPage);
      });
      paginationContainer.appendChild(pageLink);
    }
  
    highlightPageLink(currentPage);
  }
  
  // Function to highlight the current page link
  function highlightPageLink(currentPage) {
    const pageLinks = document.getElementsByClassName("page-link");
    for (let i = 0; i < pageLinks.length; i++) {
      const pageLink = pageLinks[i];
      if (parseInt(pageLink.textContent) === currentPage) {
        pageLink.classList.add("active");
      } else {
        pageLink.classList.remove("active");
      }
    }
  }
  
  // Function to handle sorting
  function handleSorting(key) {
    if (sortKey === key) {
      sortOrder = sortOrder === "asc" ? "desc" : "asc";
    } else {
      sortKey = key;
      sortOrder = "asc";
    }
    currentPage = 1;
    displayData();
    displayPagination();
  }
  
  // Event listener for column sorting
  const sortableColumns = document.querySelectorAll(".sortable");
  sortableColumns.forEach(column => {
    const key = column.getAttribute("data-key");
    column.addEventListener("click", () => {
      handleSorting(key);
    });
  });
  
  // Initial display
  displayData();
  displayPagination();

})
.catch(error => {

});

}


function handleDelete(id){
  const formData = new FormData(); // Create a new FormData object and pass the form element
  formData.append("crud", "delete")
  formData.append("id", id);
// Send the form data using AJAX
fetch('http://localhost/Prevaj/crud.php', {
method: 'POST',
body: formData,
})
.then(response => response.json())
.then(data => {
// Process the response data
})
.catch(error => {
});
window.location.href = "http://localhost/Prevaj/index.html";

}


  function handleEdit(id, name, role, company, salary){
      localStorage.setItem("id",id);
      localStorage.setItem("name",name);
      localStorage.setItem("role",role);
      localStorage.setItem("company",company);
      localStorage.setItem("salary",salary);
      window.location.href = "http://localhost/Prevaj/editForm.html"
  }
